# jQuery Bootstrap Alerts

> A jQuery plugin for displaying Bootstrap alerts via jQuery events.

## Requires
- jQuery
- Bootstrap

[Documentation](http://eltimn.github.com/jquery-bs-alerts)

[Download](https://github.com/eltimn/jquery-bs-alerts/releases)

**License**: MIT [http://www.opensource.org/licenses/mit-license.php](http://www.opensource.org/licenses/mit-license.php)
